<h1 align="center"> OMEGA V1</h1>
<p align="center">  
  
***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING ;OMEGA;MULTI+DEVICE+WHATSAPP+BOT;CREATED+BY+LORD+OMEGA;RELEASED+28.09.24" alt="Typing SVG" /></a>
  </p>
    <a href="https://ibb.co/MsM8G1b"><img src="https://i.ibb.co/bPzH2vx/IMG-20240906-154743-430.jpg" alt="IMG-20240906-154743-430" border="0"></a>
<p align="center">
<pQUEEN-RIAS align="center">
<a href="https://github.com/Toxic1239/OMEGAEDIT001 2"><img title="Author" src="https://img.shields.io/badge/Omega Gremory-black?style=for-the-badge&logo=github"></a>
<p align="center">
<a href="https://github.com/Toxic1239/followers"><img title="Followers" src="img.shields.io/github/followers/Toxic1239?color=blue&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Queen-RiasV2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Toxic1239/omega v1?color=red&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Queen-RiasV2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Toxic1239/Queen-RiasV2?color=green&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Queen-RiasV2/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Toxic1239/Queen-RiasV2?label=Watchers&color=yellow&style=flat-square"></a>

#### SETUP 
<p>IF YOU WANNA DEPLOY USING CREDS.JSON ADD THE CREDS TO SESSIONS FOLDER </p>

### 1.`First STAR 🌟 This Repo ` And Then Click Fork Below
<br>
    <a href='https://github.com/Toxic1239/Queen-RiasV2/fork' target="_blank"><img alt='Fork' src='https://img.shields.io/badge/-Fork-blue?style=for-the-badge&logo=Github&logoColor=white'/></a>

### 2. GET CREDS.JSON HERE 

<a href='https://toxxic-site.vercel.app/' target="_blank"><img alt='GET CREDS.JSON' src='https://img.shields.io/badge/Click here to get your Creds file-blue?style=for-the-badge&logo=opencv&logoColor=white'/></a> 
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>    

### STEP 2
ADD CREDS.JSON FILE TO SESSION FOLDER AND DEPLOY BELOW
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+DEPLOYMENT+PROCESS" alt="Typing SVG" /></a>
  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
### DEPLOY ON REPLIT
IF YOU DON'T HAVE A REPLIT ACCOUNT CREATE ONE AND DEPLOY 
    <br>
    <a href='https://replit.com/github/Toxic1239/Queen-RiasV2' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=white'/></a>
    

<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+ PANEL+DEPLOYMENT" alt="Typing SVG" /></a>
 
  ```bash
  * upload the OMEGA V1 Zip
  * unarchive the zip
  * delete the zip 
  * move the files to ../
* Go to console and start 
* wait for 3mins and your bot starts running
* add your WhatsApp number and link the pair code to your number
* Bot Connected
```
<br>
    <a href='https://github.com/Toxic1239/Queen-RiasV2/archive/refs/heads/main.zip' target="_blank"><img alt='DOWNLOAD ZIP' src='https://img.shields.io/badge/-Download Zip File-red?style=for-the-badge&logo=google&logoColor=white'/></a>
 <br>
    <a href='https://bot-hosting.net/?aff=1249249036259823733' target="_blank"><img alt='PANEL' src='https://img.shields.io/badge/-Deploy On Panel-green?style=for-the-badge&logo=WhatsApp&logoColor=white'/></a>
<br>
    <a href='https://youtu.be/I5L6gcc8o1Q?si=GsuswtpRoteCT4KX' target="_blank"><img alt='TUTORIAL' src='https://img.shields.io/badge/-Tutorial-black?style=for-the-badge&logo=Youtube&logoColor=red'/></a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
### DEPLOY ON TERMUX
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+ FOR TERMUX DEPLOYMENT ⟱" alt="Typing SVG" /></a>

```bash
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/Toxic1239/Queen-RiasV2
cd Queen-RiasV2
yarn install
npm start
```
 
    
### DEPLOY ON CODESPACE 
1. Deploy. `Free`
```bash
npm install
npm start
```
   <a href='https://github.com/codespaces' target="_blank"><img alt='Codespace' src='https://img.shields.io/badge/-Deploy-green?style=for-the-badge&logo=codespace&logoColor=white'/></a>

***

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>    

### CONTRIBUTIONS 
-Contributions to QUEEN-RIAS are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

<br>
    <a href='https://github.com/Toxic1239/Queen-RiasV2/issues/new/choose' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/-REPORT ISSUE-red?style=for-the-badge&logo=railway&logoColor=white'/></a>


***
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>    

### LICENSE 
-The QUEEN-RIAS is released under the [MIT License](https://opensource.org/licenses/MIT).

-Enjoy the diverse features of the Omega  to enhance your conversations and make your WhatsApp experience more interesting!

***
### DEVELOPER:
**GET In Touch with The Owner**
- [**On TELEGRAM**](https://t.me/Toxxicn_bot)
- [**CHANNEL**](https://whatsapp.com/channel/0029VayhiL342DcobX2mFD24) 
***
### WARNING

- **QUEEN-RIAS is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use QUEEN-RIAS at your own risk by keeping this warning in mind.*
  
  #### ```TOTAL REPO VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/Riasgv2/count.svg)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

 ## [WEBSITE](https://toxxic-site.vercel.app/) 
### THANKS TO:

- Myself Toxxic For making This bot
- B.m.b for his support and some cases added 
- Veran For Support
- Xeon for Some Cases
- King for Fixing Some Cases 
