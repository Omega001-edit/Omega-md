exports.first_chat = "Hello welcome to 'omega v1' "
